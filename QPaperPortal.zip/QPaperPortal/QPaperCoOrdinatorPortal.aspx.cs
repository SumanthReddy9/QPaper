﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace QPaperPortal
{
    public partial class QPaperCoOrdinatorPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                HttpCookie cookie = Request.Cookies["Teacher"];
                if (cookie != null)
                {
                    datalabel.Text = "Welcome " + cookie["name"];
                }
                string bch = cookie["branch"];
                int tid;
                int.TryParse(cookie["teacherid"], out tid);
                DataSet ds = new DataSet();
                DataSet ds2 = new DataSet();
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Marks, TeacherID FROM MCQs WHERE TeacherBranch = @bch ORDER BY TeacherID";
                string query2 = "SELECT Question, Marks,TeacherID FROM Questions WHERE TeacherBranch=@bch ORDER BY TeacherID";

                SqlCommand cmd = new SqlCommand(query, con);
                SqlCommand cmd2 = new SqlCommand(query2, con);
                cmd.Parameters.AddWithValue("@bch", bch);
                cmd2.Parameters.AddWithValue("@bch", bch);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                SqlDataAdapter adapter2 = new SqlDataAdapter(cmd2);
                adapter.Fill(ds, "AllMCQsData");
                adapter2.Fill(ds2, "AllQTNsData");
                AllMCQs.DataSource = ds;
                AllMCQs.DataBind();
                AllQTNs.DataSource = ds2;
                AllQTNs.DataBind();
               
            }
        }

        protected void AddMCQ_OnClick(object sender, EventArgs e)
        {
            string url = "MCQ.aspx?";
            url += "Back=QPaperCoOrdinatorPortal.aspx";
            Response.Redirect(url);
        }

        protected void AddQTN_OnClick(object sender, EventArgs e)
        {
            string url = "Questions.aspx?";
            url += "Back=QPaperCoOrdinatorPortal.aspx";
            Response.Redirect(url);
        }

        protected void ShowQTNS_OnClick(object sender, EventArgs e)
        {

        }

        protected void otherfaculty_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void signout_Click(object sender, EventArgs e)
        {
            if(Request.Cookies["Teacher"] != null)
            {
                HttpCookie cookie = new HttpCookie("Teacher");
                cookie.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie);
                Response.Redirect("HomePage.aspx");
            }
        }

        protected void submitqtnpaper_Click(object sender, EventArgs e)
        {
            if(Page.IsValid)
            {
                string questionpapername = txtbxquestionpapername.Text;
                HttpCookie cookie = Request.Cookies["Teacher"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                foreach(GridViewRow gvrow in AllMCQs.Rows)
                 {
                     CheckBox ckcbx = (CheckBox)gvrow.FindControl("cbmcqsSelect");
                     if(ckcbx != null && ckcbx.Checked)
                     {
                         int marks;
                         int.TryParse(gvrow.Cells[6].ToString(), out marks);
                         string query = "INSERT INTO MCQsQP(QuestionPaperName, Question, OptionA, OptionB, OptionC, OptionD,TeacherBranch) VALUES(@qpname, @question, @optiona, @optionb, @optionc, @optiond, @teacherbranch)";
                        string query2 = "INSERT INTO QuestionPaperNames(QPNames,TeacherBranch) VALUES(@qpname, @teacherbranch)";
                        SqlCommand cmd = new SqlCommand(query, con);
                         cmd.Parameters.AddWithValue("@qpname", questionpapername);
                         cmd.Parameters.AddWithValue("@question", gvrow.Cells[1].Text);
                         cmd.Parameters.AddWithValue("@optiona", gvrow.Cells[2].Text);
                         cmd.Parameters.AddWithValue("@optionb", gvrow.Cells[3].Text);
                         cmd.Parameters.AddWithValue("@optionc", gvrow.Cells[4].Text);
                         cmd.Parameters.AddWithValue("@optiond", gvrow.Cells[5].Text);
                         cmd.Parameters.AddWithValue("@marks", marks);
                         cmd.Parameters.AddWithValue("@teacherbranch",cookie["branch"] );
                         SqlCommand cmd2 = new SqlCommand(query2, con);
                         cmd2.Parameters.AddWithValue("@qpname", questionpapername);
                         cmd2.Parameters.AddWithValue("@teacherbranch", cookie["branch"]);
                         con.Open();
                         cmd.ExecuteNonQuery();
                         cmd2.ExecuteNonQuery();
                         con.Close();
                         
                     }
                 }

                 foreach(GridViewRow gvrow in AllQTNs.Rows)
                {
                    CheckBox ckcbx = (CheckBox)gvrow.FindControl("cbqtnsSelect");
                    if(ckcbx != null && ckcbx.Checked)
                    {
                        string query = "INSERT INTO QuestionsQP(QuestionPaperName, Question, TeacherBranch) VALUES(@qpname, @question, @teacherbranch)";
                        string query2 = "INSERT INTO QuestionPaperNames(QPNames,TeacherBranch) VALUES(@qpname, @teacherbranch)";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.Parameters.AddWithValue("@qpname", questionpapername);
                        cmd.Parameters.AddWithValue("@question", gvrow.Cells[1].Text);
                        cmd.Parameters.AddWithValue("@teacherbranch", cookie["branch"]);
                        SqlCommand cmd2 = new SqlCommand(query2, con);
                        cmd2.Parameters.AddWithValue("@qpname", questionpapername);
                        cmd2.Parameters.AddWithValue("@teacherbranch", cookie["branch"]);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
                Response.Redirect("QPaperCoOrdinatorPortal.aspx");

              

            }
        }

        protected void deleteall_Click(object sender, EventArgs e)
        {
                string questionpapername = txtbxquestionpapername.Text;
                HttpCookie cookie = Request.Cookies["Teacher"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "DELETE FROM MCQsQP WHERE TeacherBranch=@bch";
                string query2 = "DELETE FROM QuestionPaperNames WHERE TeacherBranch=@bch";
                string query3 = "DELETE FROM QuestionsQP WHERE TeacherBranch=@bch";
                string query4 = "DELETE FROM MCQs WHERE TeacherBranch=@bch";
                string query5 = "DELETE FROM Questions WHERE TeacherBranch=@bch";

                SqlCommand cmd = new SqlCommand(query, con);
                SqlCommand cmd2 = new SqlCommand(query2, con);
                SqlCommand cmd3 = new SqlCommand(query3, con);
                SqlCommand cmd4 = new SqlCommand(query4, con);
                SqlCommand cmd5 = new SqlCommand(query5, con);

                cmd.Parameters.AddWithValue("@bch", cookie["branch"]);
                cmd2.Parameters.AddWithValue("@bch", cookie["branch"]);
                cmd3.Parameters.AddWithValue("@bch", cookie["branch"]);
                cmd4.Parameters.AddWithValue("@bch", cookie["branch"]);
                cmd5.Parameters.AddWithValue("@bch", cookie["branch"]);

                con.Open();
                cmd.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();
                cmd3.ExecuteNonQuery();
                cmd4.ExecuteNonQuery();
                cmd5.ExecuteNonQuery();
                con.Close();
                Response.Redirect("QPaperCoOrdinatorPortal.aspx");
        }
    }
}