﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace QPaperPortal
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                positionddl.Items.Add(new ListItem("Co-Ordinator","C"));
                positionddl.Items.Add(new ListItem("Faculty","F"));
                departmentnameddl.Items.Add(new ListItem("CSE", "CSE"));
                departmentnameddl.Items.Add(new ListItem("IT", "IT"));
                departmentnameddl.Items.Add(new ListItem("CCE   ", "CCE"));
            }
        }

        protected void close_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("QPaperAdminPortal.aspx");
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                int id;
                int.TryParse(txtbxuserid.Text, out id);
                string name = txtbxteachername.Text;
                string department = departmentnameddl.SelectedValue;
                string position = positionddl.SelectedValue;
                string password = txtpassword.Text;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source = (localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "INSERT INTO Teacher(Id,Name,Department,Position,Password) VALUES(@id,@name, @department, @position, @password)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@department", department);
                cmd.Parameters.AddWithValue("@position", position);
                cmd.Parameters.AddWithValue("@password", password);
                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    Response.Redirect("QPaperAdminPortal.aspx");
                }
                catch(Exception) { }
                finally
                {
                    con.Close();
                }
            }

        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source = (localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
            string query = "SELECT Id FROM Teacher";
            SqlCommand cmd = new SqlCommand(query, con);
            try
            {
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                args.IsValid = true;
                while(reader.Read())
                {
                    if(reader["Id"].ToString() == txtbxuserid.Text)
                    {
                        args.IsValid = false;
                        break;
                    }
                }
            }
            catch(Exception )
            {

            }
            finally
            {
                con.Close();
            }
        }


    }
}