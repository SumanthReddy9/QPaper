﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace QPaperPortal
{
    public partial class QPaperAdminPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                HttpCookie cookie = Request.Cookies["Teacher"];
                if(cookie != null)
                {
                    datalabel.Text = "Welcome " + cookie["name"];

                }
                branchddl.Items.Add("Select");
                branchddl.Items.Add("CSE");
                branchddl.Items.Add("IT");
                branchddl.Items.Add("CCE");
            }
        }

        protected void signout_Click(object sender, EventArgs e)
        {
           if(Request.Cookies["Teacher"] !=  null)
            {
                HttpCookie cookie = new HttpCookie("Teacher");
                cookie.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie);
                Response.Redirect("HomePage.aspx");

            }
        }

        protected void registerid_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }

        protected void branchddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(branchddl.SelectedItem.Text != "Select")
                      questionpapersddl.Visible = true;
            else
            {
                questionpapersddl.Visible = false;
            }
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
            string query = "SELECT DISTINCT QPNames FROM QuestionPaperNames WHERE TeacherBranch=@bch";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@bch", branchddl.SelectedItem.Text);
            questionpapersddl.Items.Clear();
            questionpapersddl.Items.Add("Select");
            try
            {
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    questionpapersddl.Items.Add(reader["QPNames"].ToString());
                }
            }
            catch(Exception )
            {

            }
            finally
            {
                con.Close();
            }
        }

        protected void questionpapersddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            DataSet ds2 = new DataSet();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
            string query = "SELECT Question, OptionA, OptionB, OptionC, OptionD FROM MCQsQP WHERE TeacherBranch=@bch and QuestionPaperName=@qpname";
            string query2 = "SELECT Question FROM QuestionsQP WHERE TeacherBranch=@bch and QuestionPaperName=@qpname";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@bch", branchddl.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@qpname", questionpapersddl.SelectedItem.Text);
            SqlCommand cmd2 = new SqlCommand(query2, con);
            cmd2.Parameters.AddWithValue("@bch", branchddl.SelectedItem.Text);
            cmd2.Parameters.AddWithValue("@qpname", questionpapersddl.SelectedItem.Text);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            SqlDataAdapter adapter2 = new SqlDataAdapter(cmd2);
            adapter.Fill(ds, "mcqsdata");
            adapter2.Fill(ds2, "qtnsdata");
            QPaperMCQs.DataSource = ds;
            QPaperQTNs.DataSource = ds2;
            this.DataBind();
        }
    }
}