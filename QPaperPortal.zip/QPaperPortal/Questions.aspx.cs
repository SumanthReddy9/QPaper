﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace QPaperPortal
{
    public partial class Questions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void close_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect((string)Request.QueryString["Back"]);
        }

        protected void submit_Click(object sender, EventArgs e)
        {
           if (Page.IsValid)
            {
                HttpCookie cookie = Request.Cookies["Teacher"];
                string question = txtbxqtn.Text;
                int marks;
                int.TryParse(txtbxmarks.Text, out marks);
                int teacherid;
                int.TryParse(cookie["teacherid"], out teacherid);
                string teacherbranch = cookie["branch"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "INSERT INTO Questions(Question, Marks, TeacherID, TeacherBranch) VALUES(@question, @marks, @teacherid, @teacherbranch)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@question", question);
                cmd.Parameters.AddWithValue("@marks", marks);
                cmd.Parameters.AddWithValue("@teacherid", teacherid);
                cmd.Parameters.AddWithValue("@teacherbranch", teacherbranch);
                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    Response.Redirect(Request.QueryString["Back"]);
                }
                catch (Exception) { }
                finally
                {
                    con.Close();
                }
            }

        }

       
    }
}