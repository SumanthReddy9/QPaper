﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace QPaperPortal
{
    public partial class QPaperTeacherPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             if (!IsPostBack)
            {
                DataSet ds = new DataSet();
                DataSet ds2 = new DataSet();
                HttpCookie cookie = Request.Cookies["Teacher"];
                if (cookie != null)
                {
                    datalabel.Text = "Welcome " + cookie["name"];
                }
                int tid;
                int.TryParse(cookie["teacherid"], out tid);
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "SELECT Question, OptionA, OptionB, OptionC, OptionD, Answer, Marks FROM MCQs WHERE TeacherID=@tid";
                string query2 = "SELECT Question, Marks FROM Questions WHERE TeacherID=@tid";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlCommand cmd2 = new SqlCommand(query2, con);
                cmd.Parameters.AddWithValue("@tid", tid);
                cmd2.Parameters.AddWithValue("@tid", tid);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                SqlDataAdapter adapter2 = new SqlDataAdapter(cmd2);
                adapter.Fill(ds, "mcq");
                adapter2.Fill(ds2, "qtn");
                lblMCQs.DataSource = ds;
                lblMCQs.DataBind();
                lblQTNs.DataSource = ds2;
                lblQTNs.DataBind();
            }
        }

        protected void signout_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Teacher"] != null)
            {
                HttpCookie cookie = new HttpCookie("Teacher");
                cookie.Expires = DateTime.Now.AddDays(-1d);
                Response.Cookies.Add(cookie);
                Response.Redirect("HomePage.aspx");
            }
        }

        protected void AddMCQ_OnClick(object sender, EventArgs e)
        {
            string url = "MCQ.aspx?";
            url += "Back=QPaperTeacherPortal.aspx";
            Response.Redirect(url);        }

        protected void AddQTN_OnClick(object sender, EventArgs e)
        {
            string url = "Questions.aspx?";
            url += "Back=QPaperTeacherPortal.aspx";
            Response.Redirect(url);
        }

        protected void ShowQTNS_OnClick(object sender, EventArgs e)
        {

        }
    }
}