﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace QPaperPortal
{
    public partial class MCQ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void close_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect((string)Request.QueryString["Back"]);
        }

        protected void submit_Click(object sender, EventArgs e)
        {
           if (Page.IsValid)
            {
                string question = txtbxqtn.Text;
                string optiona = txtbxoptiona.Text;
                string optionb = txtbxoptionb.Text;
                string optionc = txtbxoptionc.Text;
                string optiond = txtbxoptiond.Text;
                int marks;
                int.TryParse(txtbxmarks.Text,out marks);
                string answer = txtbxanswer.Text;
                HttpCookie cookie = Request.Cookies["Teacher"];
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query2 = "INSERT INTO MCQs VALUES(@question,@optiona,@optionb,@optionc,@optiond,@answer,@marks,@teacherid,@teacherbranch)";
                SqlCommand cmd2 = new SqlCommand(query2, con);
                cmd2.Parameters.AddWithValue("@question", question);
                cmd2.Parameters.AddWithValue("@optiona", optiona);
                cmd2.Parameters.AddWithValue("@optionb", optionb);
                cmd2.Parameters.AddWithValue("@optionc", optionc);
                cmd2.Parameters.AddWithValue("@optiond", optiond);
                cmd2.Parameters.AddWithValue("@answer", answer);
                cmd2.Parameters.AddWithValue("@marks", marks);
                int teacherid;
                int.TryParse(cookie["teacherid"],out teacherid);
                cmd2.Parameters.AddWithValue("@teacherid", teacherid);
                cmd2.Parameters.AddWithValue("@teacherbranch", cookie["branch"]);
                try
                {
                    con.Open();
                    cmd2.ExecuteNonQuery();
                    Response.Redirect(Request.QueryString["Back"]);
                }
                catch(Exception) { }
                finally
                {
                    con.Close();
                }

            }
        }
    }
}