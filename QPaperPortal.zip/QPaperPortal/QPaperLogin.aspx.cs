﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Windows;

namespace QPaperPortal
{
    public partial class QPaperLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if((string)Session["valid"] == "false")
            {
               // ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", "Invalid userid or password");
                ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "ClientScript", "alert('Invalid details')", true);
            }
            else
            {
                invalidlbl.Text = " ";
            }

            HttpCookie cookie = Request.Cookies["Teacher"];
            if(cookie != null)
            {
                Response.Redirect(cookie["tech"]);
            }
        }
        protected void loginClick(object sender , EventArgs e)
        {
            int userid;
            int.TryParse(uid.Text, out userid);
            HttpCookie cookie = Request.Cookies["Teacher"];
            if(cookie == null)
            {
                cookie = new HttpCookie("Teacher");
                cookie.Expires = DateTime.Now.AddYears(1);
            }
            string password = psd.Text;
            string cod = "C";
            string adm = "A";
             SqlConnection con = new SqlConnection();
             con.ConnectionString = "Data Source = (localdb)\\MSSQLlocalDB;Initial Catalog = Department;Integrated Security = True";
             string query = "SELECT Id,Password, Name,Department,Position  FROM Teacher WHERE Id =" + userid;
             SqlCommand cmd = new SqlCommand(query, con);
             try
             {
                 con.Open();
                 SqlDataReader reader = cmd.ExecuteReader();
                 if(reader.Read())
                {
                    if(reader["Password"].ToString() == password)
                    {
                        Session["valid"] = "true";
                        //Session["details"] = reader["Name"].ToString();s
                        cookie["name"] = reader["Name"].ToString();
                       // Session["teacherid"] = reader["Id"].ToString();
                        // Session["branch"] = reader["Department"].ToString();
                        cookie["branch"] = reader["Department"].ToString();
                        cookie["teacherid"] = reader["Id"].ToString();
                        if (reader["Position"].ToString() == cod)
                        {
                            cookie["tech"] = "QPaperCoOrdinatorPortal.aspx";
                            Response.Cookies.Add(cookie);
                            Response.Redirect("QPaperCoOrdinatorPortal.aspx");
                        }
                        else if(reader["Position"].ToString() == adm)
                        {
                            cookie["tech"] = "QPaperAdminPortal.aspx";
                            Response.Cookies.Add(cookie);
                            Response.Redirect("QPaperAdminPortal.aspx");
                        }
                        else
                        {
                            cookie["tech"] = "QPaperTeacherPortal.aspx";
                            Response.Cookies.Add(cookie);
                            Response.Redirect("QPaperTeacherPortal.aspx");
                        }
                    }
                    else
                    {
                        Session["valid"] = "false";
                        invalidlbl.Text = "Invalid Password";
                        Response.Redirect("QPaperLogin.aspx");
                    }
                }
                else
                {
                    Session["valid"] = "false";
                    invalidlbl.Text = "Invalid Userid";
                    Response.Redirect("QPaperLogin.aspx");                
                }
                
             }
             catch(Exception )
             {

             }
             finally
             {
                 con.Close();
             }
               
        }
    }
}