﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace QPaperPortal
{
    public partial class QPaperPortal : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLlocalDB;Initial Catalog=Department;Integrated Security=True";
                string query = "SELECT Id,Name,Department,Position FROM Teacher ORDER BY Position, Department";
                SqlCommand cmd = new SqlCommand(query, con);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    TeachersData.DataSource = reader;
                    TeachersData.DataBind();
                }
                catch
                {
                    
                }
                finally
                {
                    con.Close();
                }
            }
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("QPaperLogin.aspx");
        }
    }
}